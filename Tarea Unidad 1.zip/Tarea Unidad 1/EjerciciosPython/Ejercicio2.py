"""Problema 2. Frecuencia de palabras en un texto. 
Escribe una función que reciba por parámetro una lista de palabras y la ruta a 
un fichero de texto y devuelva un diccionario que muestre cuantas veces 
aparecen las dis
ntas palabras de la lista en el fichero de texto. Haz un pequeño 
programa que la ponga a prueba. 
Requisitos: 
1. Eliminar signos de puntuación y conver
r todo a minúsculas. 
2. Usar un diccionario donde la clave sea la palabra y el valor su frecuencia. 
3. Mostrar las palabras y sus frecuencias de forma ordenada por la palabra."""


def contar_frecuencia_palabras(palabras, ruta_fichero):
    import string

    # Inicializar el diccionario de frecuencias
    frecuencia = {palabra: 0 for palabra in palabras}

    # Leer el contenido del fichero
    with open(ruta_fichero, 'r', encoding='utf-8') as fichero:
        contenido = fichero.read().lower()

        # Eliminar signos de puntuación
        contenido = contenido.translate(str.maketrans('', '', string.punctuation))

        # Dividir el contenido en palabras
        palabras_en_fichero = contenido.split()

        # Contar la frecuencia de las palabras
        for palabra in palabras_en_fichero:
            if palabra in frecuencia:
                frecuencia[palabra] += 1

    return dict(sorted(frecuencia.items()))




if __name__ == "__main__":
    palabras = ["hola", "mundo", "texto", "prueba", "python"]
    ruta = "FicheroTexto.txt"  

    resultado = contar_frecuencia_palabras(palabras, ruta)

for palabra, freq in resultado.items():
        print(f"{palabra}: {freq}")


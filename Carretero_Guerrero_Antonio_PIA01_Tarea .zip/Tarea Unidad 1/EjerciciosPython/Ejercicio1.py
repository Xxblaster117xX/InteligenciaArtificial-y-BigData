
""" Ejercicio 1: Procesamiento de una lista de enteros. 
Crea una función que reciba una lista de enteros por parámetro y devuelva otra 
lista, de acuerdo a las siguientes acciones: 
1. Eliminar los números nega
vos de la lista. 
2. Eliminar los valores que están repe
dos, quedándonos con uno de ellos. 
3. Ordenar los números resultantes de menor a mayor. 
Por ejemplo, si le pasara [4, -1, 2, 4, 3, -5, 2], debería retornar [2,3,4]. """

def procesar_lista(lista):
   
    numerosNegativosEliminados= [numero for numero in lista if numero >= 0]
    numerosSinRepetidos = list(set(numerosNegativosEliminados))
    numerosOrdenados=sorted(numerosSinRepetidos)
    return numerosOrdenados

resultado = procesar_lista([4, -1, 2, 4, 3, -5, 2])
print(resultado) 
